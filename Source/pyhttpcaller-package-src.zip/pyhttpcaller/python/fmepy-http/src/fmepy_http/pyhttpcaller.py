import fme
import fmeobjects
import fmewebservices
import requests

class PyHttpCallerFactory(object):
    def __init__(self, xformer_name, params):
        self.xformer_name = xformer_name
        self.session = None
        self.logger = fmeobjects.FMELogFile()
        self.fmesession = fmeobjects.FMESession()
        self.params = params
        self.web_connection_name = None
    def _log_info(self, msg):
        self.logger.logMessageString('{} (PyHttpCaller): {}'.format(self.xformer_name, msg), fmeobjects.FME_INFORM)
    def _log_error(self, msg):
        self.logger.logMessageString('{} (PyHttpCaller): {}'.format(self.xformer_name, msg), fmeobjects.FME_ERROR)
    def _log_warn(self, msg):
        self.logger.logMessageString('{} (PyHttpCaller): {}'.format(self.xformer_name, msg), fmeobjects.FME_WARN)
    def _log_debug(self, msg):
        pass
        #self.logger.logMessageString('{} (PyHttpCaller): {}'.format(self.xformer_name, msg), fmeobjects.FME_WARN)
       
    def eval_param(self, feature, v):
        if v.startswith('@'):
            v = feature.performFunction(v)
        return self.fmesession.decodeFromFMEParsableText(v)
    def _init_web_connection(self, nc_name):
        self._log_info('Using named connection `{}`'.format(nc_name))
        connection_manager = fmewebservices.FMENamedConnectionManager()
        web_connection = connection_manager.getNamedConnection(nc_name)
        if web_connection is None:
            self._log_error('named connection `{}` could not be found'.format(nc_name))
            raise fmeobjects.FMEException('CONFIGURATION_ERROR')
        if not (isinstance(web_connection, fmewebservices.FMEBasicConnection) and 'HTTP Authentication' == web_connection.getServiceName()):
            self._log_error('Only HTTP Authentication can be used')
            raise fmeobjects.FMEException('CONFIGURATION_ERROR')
        self.session = requests.Session()
        self.session.auth = (web_connection.getUserName(), web_connection.getPassword())
        self.web_connection_name = nc_name
    def input(self, feature):
        try:
            params = {}
            for k, v in self.params.items():
                if '<Unused>' == v: continue
                if not len(v.strip()): continue
                if k in ['ADDITIONAL_URL_PARAMETERS', 'CUSTOM_HEADERS']:
                    values = [self.eval_param(feature, x) for x in v.split(';')]
                    v = dict(zip(*[iter(values)]*2))
                elif 'MULTIPARTS' == k:
                    values = [self.eval_param(feature, x) for x in v.split(';')]
                    v = {n: x for n,*x in zip(*[iter(values)]*6)}
                    """ Example:
                    {
                          'a': ['FileUpload', 'SOURCE_FILE', 'C:\\temp\\fmepy_reportnet.reader.Reportnet3Reader.log', 'MIME_TYPE', 'application/octet-stream']
                        , 'b': ['FileUpload', 'SOURCE_FILE', '0', 'MIME_TYPE', 'application/octet-stream']
                        , 'c': ['StringUpload', 'SOURCE_EXPRESSION', 'asdf 0 eee', 'MIME_TYPE', 'text/plain']
                    }
                    """
                else:
                    v = self.eval_param(feature, v)
                params[k] = v
            
            for k,v in params.items():
                self._log_debug('{}: {}'.format(k,v))
            if 'YES' == params.get('HTTP_AUTH_GROUP', ''):
                if not self.web_connection_name == params['AUTH_NAMED_CONNECTION']:
                    self._init_web_connection(params['AUTH_NAMED_CONNECTION'])
            elif not self.session:
                self.session = requests.Session()
            target_url, http_method = (params[k] for k in ('TARGET_URL', 'HTTP_METHOD'))
            # Log URL 
            self._log_info('{} ({})'.format(target_url, http_method))
            #self.session.headers.update(params.get('CUSTOM_HEADERS', {}))
            
            req = requests.Request(
                  http_method
                , target_url
                , headers=params.get('CUSTOM_HEADERS', {})
                , params=params.get('ADDITIONAL_URL_PARAMETERS', {})
            )
            
            prepared = self.session.prepare_request(req)


            if 'FME_DISCLOSURE_OPEN' == params.get('UPLOAD_GROUP', ''):
                upload_type = params['UPLOAD_TYPE']
                if 'SpecifyUploadBody' == upload_type and params.get('UPLOAD_BODY', ''):
                    prepared.prepare_body(params['UPLOAD_BODY'].encode('utf8'), None)
                    prepared.headers['Content-Type'] = '{}; charset=UTF-8'.format(params.get('UPLOAD_CONTENT_TYPE', 'text/plain'))
                elif 'UploadFromFile' == params['UPLOAD_TYPE']:
                    prepared.data = open(params['UPLOAD_FILE'], 'rb')
                    prepared.headers['Content-Type'] = params.get('UPLOAD_CONTENT_TYPE', 'application/octet-stream')
                elif 'YES' == params.get('IS_MULTIPART_UPLOAD', ''):
                    files = {}
                    for n, (p1, _, p3, _, p5) in params.get('MULTIPARTS', {}).items():
                        if 'FileUpload' == p1:
                            files[n] = (n, open(p3, 'rb'), p5)
                        elif 'StringUpload' == p1:
                            files[n] = (n, p3.encode('utf8'), '{}; charset=UTF-8'.format(p5))
                    prepared.prepare_body(None, files)
            try:
                timeout = (int(params['CONNECTION_TIMEOUT_LENGTH']), int(params['TRANSFER_TIMEOUT_LENGTH']))
                verify = 'Yes' == params.get('VERIFY_SSL_CERTIFICATES','')
                resp = self.session.send(prepared, timeout=timeout, verify=verify)
                if params.get('STATUS_CODE_ATTR'):
                    feature.setAttribute(params.get('STATUS_CODE_ATTR'), resp.status_code)
                resp.raise_for_status()
                if 'Attribute' == params.get('SAVE_FILE', ''):
                    encoding = params['TARGET_ATTR_ENCODING']
                    data = None
                    if 'auto-detect' == encoding:
                        self._log_info(f'detected encoding `{resp.encoding}`')
                        data = resp.text
                    elif 'fme-binary' == encoding:
                        data = resp.content
                    else:
                        data = resp.content.decode(encoding)
                    feature.setAttribute(params['TARGET_ATTR'], data)
                else:
                    raise NotImplementedError('Only downloads to attribute implemented')
                if params.get('RESPONSE_HEADER_LIST_ATTR', ''):
                    list_name = '{}{{}}'.format(params.get('RESPONSE_HEADER_LIST_ATTR', ''))
                    names, values = zip(*resp.headers.items())
                    feature.setAttribute(f'{list_name}.name', list(names))
                    feature.setAttribute(f'{list_name}.value', list(values))
                    self._log_info(list_name)
            except NotImplementedError as e:
                self._log_error(str(e))
                feature.setAttribute('fme_rejection_code', 'NOT_IMPLEMENTED')
            except Exception as e:
                self._log_error(str(e))
                if params.get('ERROR_ATTR', ''):
                    feature.setAttribute(params['ERROR_ATTR'], str(e))
                feature.setAttribute('fme_rejection_code', 'HTTP_ERROR')
        except fmeobjects.FMEException as e:
            feature.setAttribute('fme_rejection_code', e.message)
        self.pyoutput(feature)
    def close(self):
        del self.fmesession
        del self.logger
        