# fme-reportnet

This is a Python package containing the code for the Reportnet 3 FME format.
It belongs to the [eea.reportnet3 package on FME Hub](https://hub.fme.co/publishers/eea/packages/reportnet3).

The Python code here is only to be used by the eea.reportnet3 package.
